let todos=[
  {id:1, title:"Learn React", status:false},
  {id:2, title:"Learn Node", status:true},
  {id:3, title:"Learn MongoDB", status:false},
];//dummy database

export default todos;

//here I am using export default because I am exporting only one thing from this file