import express from "express";
import todoRoutes from "./routes/todo.route.js";
import authRoutes from "./routes/auth.route.js";

const app = express();  

app.use(express.json()); //middleware

app.get("/", (req, res) => {
  res.send("Hello World!");
});

app.use("/todo", todoRoutes);
app.use("/auth", authRoutes);
// this app is your backend server
// you can use it however you want




// app.get("/todo/:id",(req,res)=>{
//   //req is for checking what the client is sending
//   //res is for sending the response to the client
//   // /todo/1
//   //here id=1 which is known as route parameter
//   const {id}=req.params;

//   const todo=todos.find((t)=>t.id===Number(id));
//   if(todo){
//     res.send(todo);
//   }else{
//     res.status(404).send({message:"Todo not found"});
//   }
// } );

// app.post("/todo", (req, res) => {
//   const { title } = req.body;
//   const todo = {
//     id: todos.length + 1,
//     title,
//     status: false,
//   };
//   todos.push(todo);
//   console.log(todos);
  
//   res.send(todo);
// });

// app.put("/todo/:id", (req, res) => {
//   const { id } = req.params;
//   const { title } = req.body;
//   const todo = todos.find((t) => t.id === Number(id));
//   if (todo) {
//     todo.title = title;
//     res.send(todo);
//   } else {
//     res.status(404).send({ message: "Todo not found" });
//   }
// });

// app.delete("/todo/:id", (req, res) => {
//   const { id } = req.params;
//   const index = todos.findIndex((t) => t.id === Number(id));
//   if (index !== -1) {
//     todos.splice(index, 1);
//     res.send({ message: "Todo deleted successfully" });
//   } else {
//     res.status(404).send({ message: "Todo not found" });
//   }
// })
app.listen(5000, () => {
  console.log("Server is running on port 5000");
});