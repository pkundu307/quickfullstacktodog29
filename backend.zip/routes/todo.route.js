import { getTodos, addTodo } from "../controllers/todo.controller.js";
import express from "express";
const router = express.Router();
router.get("/todos", getTodos);
router.post("/todo", addTodo);

export default router;