import todos from "../models/todo.schema.js";

export const getTodos = (req, res) => {
  res.send(todos);
}

export const addTodo = (req, res) => {
 const { title } = req.body;
  const todo = {
    id: todos.length + 1,
    title,
    status: false,
  };
  todos.push(todo);
  console.log(todos);
  
  res.send(todo);
}

// i am not using export default because i can export multiple things from this file