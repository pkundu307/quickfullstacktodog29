import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";

let user =[]


const secretKey = "sureTrust"

export const register = (req, res) => {
    const { username, email, password } = req.body;
    const existingUser = user.find((u) => u.email === email);
    if (existingUser) {
        return  res.status(400).send({ message: "User already exists" });
    }
    const hashedPassword = bcrypt.hashSync(password, 10);
    console.log(`before hashing password: ${password}`);
    
    const newUser = { username, email, password: hashedPassword };
    user.push(newUser);
    console.log('====================================');
    console.log(user);
    console.log('====================================');
    res.status(201).send({ message: "User registered successfully" });
}

export const login = (req, res) => {
    const { email, password } = req.body;
    const existingUser = user.find((u) => u.email === email);
    console.log(existingUser,'user exist');
    
    if (!existingUser) {
        return res.status(400).send({ message: "User does not exist" });
    }
    const isPasswordValid = bcrypt.compareSync(password, existingUser.password);
    if (!isPasswordValid) {
        return res.status(400).send({ message: "Invalid password" });
    }
    console.log(isPasswordValid);
    const token = jwt.sign({ email: existingUser.email, username: existingUser.username }, secretKey, { expiresIn: "2160h" });
    res.send({ message: "Login successful", token });
}
    
export const protectedRoute = (req, res) => {
    res.send({ message: "You have accessed a protected route", user: req.user });
}